from django.shortcuts import render
from datetime import datetime
# Create your views here.


notes_list=[]
def home(request):
    return  render(request,'notes/home.html',{'num_list':reversed(notes_list)})


def create_notes(request):
    if request.method=='POST':
        title=request.POST.get('title')
        content=request.POST.get('content')
        created=datetime.now().strftime('%Y-%m-%d %h-%M')
        note={'title':title,'content':content,'created':created}
        notes_list.append(note)
    return render(request,'notes/creates_notes.html')



def about(request):
    return render(request,'notes/about.html')


def contact(request):
    return render(request,'notes/contact.html')