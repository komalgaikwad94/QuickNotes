from django import forms

class ContactForm(forms.Form):
    name=forms.CharField(label='Your Name',max_length=100)
    email=forms.EmailField(label='Enter Email')
    message=forms.CharField(label='Message',widget=forms.Textarea)

    def clean_name(self):
        name=self.cleaned_data['name']
        if "@" in name:
            raise forms.ValidationError("Name should not contain '@' ")
        return name

class FieldTypeDemoForm(forms.Form):
    char=forms.CharField(label="Char Field")
    integer=forms.IntegerField(label="Integer Field")
    boolean=forms.BooleanField(label="Boolean Field",required=False)
    choice=forms.ChoiceField(label="Choice Field",choices=[("1","Option 1"),("2","Option 2")])
    file=forms.FileField(label="File Field",required=False)
    date=forms.DateField(label="Date Field",widget=forms.SelectDateWidget)


class StyledForm(forms.Form):
    username=forms.CharField(label="UserName",max_length=100,widget=forms.TextInput(attrs={'class':'form-control','placeholder':'Enter UserName'}))
    password=forms.CharField(label="Password",widget=forms.PasswordInput(attrs={'class':'form-control'}))




