from django.shortcuts import render
from .models import ContactQuery
from .forms import ContactForm
# Create your views here.

contact_queries=[]

def home(request):
    return render(request,'feedback_app/home.html')


def about(request):
    return render(request,'feedback_app/about.html')


def contact_query_view(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            form.save()
            return render(request, 'feedback_app/contact.html',
                          {'form': ContactForm(),
                           'message': 'Query submitted successfully',
                           'show_button': True})
    else:
        form = ContactForm()
        return render(request, 'feedback_app/contact.html', {'form': form})


def contact_queries_list_view(request):
    return render(request, 'feedback_app/contact_queries_list.html', {'queries': contact_queries})
