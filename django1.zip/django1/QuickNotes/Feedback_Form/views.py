from django.shortcuts import render, redirect
from .forms import FeedbackForm

# Create your views here.

feedback_storage = [] #in memory storage

def feedback_form_view(request):
    if request.method == "POST":
        form = FeedbackForm(request.POST)
        if form.is_valid():
            feedback_storage.append(form.cleaned_data) #convert data into dictionary format
            return redirect("feedback_list")

        else:
            form = FeedbackForm()
            return render(request, "feedback_app/feedback_form.html", {"form": form,'msg':'Something went wrong'})
    form = FeedbackForm()
    return render(request, "feedback_app/feedback_form.html", {"form": form})


def feedback_list_view(request):
    return render(request, "feedback_app/feedback_list.html", {"feedbacks": feedback_storage})



