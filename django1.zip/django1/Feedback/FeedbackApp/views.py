from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, redirect
from .forms import FeedbackForm, ContactForm

feedback_storage = []
contact_queries = []

def home_view(request):
    return render(request, 'feedback_app/home.html')

def about_view(request):
    return render(request, 'feedback_app/about.html')

def contact_view(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            contact_queries.append(form.cleaned_data)
            return render(request, 'feedback_app/contact.html', {
                'form': ContactForm(),
                'message': 'Query submitted successfully!',
                'show_button': True
            })
    else:
        form = ContactForm()
    return render(request, 'feedback_app/contact.html', {'form': form})

def feedback_form_view(request):
    if request.method == 'POST':
        form = FeedbackForm(request.POST)
        if form.is_valid():
            feedback_storage.append(form.cleaned_data)
            return redirect('/feedback/feedback/list')
    else:
        form = FeedbackForm()
    return render(request, 'feedback_app/feedback_form.html', {'form': form})

def feedback_list_view(request):
    return render(request, 'feedback_app/feedback_list.html', {
        'feedbacks': feedback_storage
    })

def contact_queries_list_view(request):
    return render(request, 'feedback_app/contact_queries_list.html', {
        'queries': contact_queries
    })
