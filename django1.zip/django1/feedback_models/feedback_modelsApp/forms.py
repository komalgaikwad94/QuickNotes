from django import forms
from .models import ContactQuery

class ContactForm(forms.Form):
    full_name=forms.TextInput(attrs={'class':'form-control'})
    phone=forms.TextInput(attrs={'class':'form-control'})
    email=forms.TextInput(attrs={'class':'form-control'})
    query=forms.Textarea(attrs={'class':'form-control'})



