from django import forms

class Login_Form(forms.Form):
    name=forms.CharField(label="Enter Name" ,max_length=100)
    address=forms.CharField(label="Enter Address",max_length=100)
    Phone_Number=forms.IntegerField
    email=forms.EmailField(label="Enter Email")
    password=forms.CharField(label="Enter Password",widget=forms.PasswordInput(attrs={'class':'form-control'}))
    confirm_password=forms.CharField(label="Confirm Password",widget=forms.PasswordInput(attrs={'class':'form-control'}))
    message=forms.CharField(label="Enter message",widget=forms.Textarea)



