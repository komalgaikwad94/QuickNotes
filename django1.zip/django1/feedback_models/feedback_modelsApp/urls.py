from django.urls import path
from  . import views

app_name = 'feedback_models'

urlpatterns = [
    path('home/',views.home,name='home'),
    path('about/',views.about,name='about'),
    path('contact/',views.contact_query_view,name='contact'),
    path('contact/queries/', views.contact_queries_list_view, name='contact_queries_list')
]
