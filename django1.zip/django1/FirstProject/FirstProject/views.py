from django.http import HttpResponse
from django.shortcuts import render
from fontTools.misc.cython import returns


def my_view(request):
    return  render(request,'Day1.html')

def without_temp(request):
    cnt="""
    <h1>Hello</h1>
    <p>How are you</p>
    <b>Where are you going</b>

    """
    return  HttpResponse(cnt)

def without_variable(request):
    return  HttpResponse("<h1>This is another page without variables and without templates</h1>")

def members(request):
    return HttpResponse("Hello world!")

def show_var(request):
    num1=50
    num2=10
    num3=num1+num2

    context={
        "name":"Raj",
        "Age":40,
        "Position":"Senior DEV",
        "Email":"abc@gmail.com",
        "num1":10,
        "num2":20,
        "num3":num3
    }
    return render(request,'info.html',context)

def Directives(request):
    students=[
        {"Name":"Satish", "Marks":100},
        {"Name":"Divya","Marks":93},
        {"Name":"Shraddha","Marks":45},
        {"Name":"Tulsi","Marks":89}

        ]

    return render(request,"Directive.html",{"students":students})





