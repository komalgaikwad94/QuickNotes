from django.urls import path
from . import views

urlpatterns = [
    path('', views.form_home, name='form_home'),
    path('contact/', views.contact_form_view, name='contact_form'),
    path('fields',views.field_type_view,name='field_type_view'),
    path('style',views.styled_form,name="styled_form")

    ]