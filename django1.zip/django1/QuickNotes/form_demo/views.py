from django.shortcuts import render
from .forms import (ContactForm,FieldTypeDemoForm,StyledForm)



def form_home(request):
    return render(request,'form/home.html')


def contact_form_view(request):
    form=ContactForm()
    if request.method=="POST":
        form=ContactForm(request.POST)
        if form.is_valid():
            return render(request,'form/success.html',{'form':form})
    return render(request,'form/form_template.html',{"form": form, "title": "ContactForm"})


def field_type_view(request):
    form=FieldTypeDemoForm()
    if request.method=='POST':
        form=FieldTypeDemoForm(request.POST)
        form=FieldTypeDemoForm(request.POST,request.FILES)
        if form.is_valid():
            return render(request,'form/success.html',{"form": form})
    return render(request,'form/form_template.html',{'form':form,"title":"FieldTypeDemoForm"})

def styled_form(request):
    form=StyledForm()
    if request.method=='POST':
        form=StyledForm(request.POST)
        if form.is_valid():
            return render(request,'form/success.html',{"forms":form})
    return render(request,'form/form_template.html',{'form':form,"title":"StyledForm"})






