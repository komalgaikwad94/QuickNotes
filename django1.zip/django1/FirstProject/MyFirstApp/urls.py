from django.contrib import admin
from django.urls import path
from .views import *

urlpatterns=[
    path('intro/',FirstApp,name='Introduction'),
    path('nav/',Nav,name='navbar')
]