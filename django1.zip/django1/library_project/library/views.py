from django.shortcuts import render
from django.contrib.auth import login
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.decorators import login_required, user_passes_test
from django.db.models import Count
from django.http import HttpResponse
from .models import  Author
from .forms import AuthorForm



# Create your views here.
#-----Admin check decorator--------
def admin_required(view_func):
    return user_passes_test(lambda u:u.is_superuser)(view_func)


@login_required
@admin_required
def add_author(request):
    if request.method == 'POST':
        form = AuthorForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = AuthorForm()
    return render(request, 'library/author_form.html', {'form': form, 'action': 'Add'})


