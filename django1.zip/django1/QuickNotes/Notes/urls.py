from django.urls import path
from . import views

urlpatterns=[
    path('',views.home,name='home'),
    path('create/',views.create_notes,name='create_notes'),
    path('about/',views.about,name='about'),
    path('contact/',views.contact,name='contact')

]
