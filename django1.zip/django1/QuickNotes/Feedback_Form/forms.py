from django import forms


class FeedbackForm(forms.Form):
    name=forms.CharField(label='Enter name',max_length=100,widget=forms.TextInput(attrs={'class':'form-control'}))
    email=forms.EmailField(label='Enter Email',widget=forms.TextInput(attrs={'class':'form-control'}))
    message=forms.CharField(label='Enter message',widget=forms.Textarea(attrs={'class':'form-control'}))


