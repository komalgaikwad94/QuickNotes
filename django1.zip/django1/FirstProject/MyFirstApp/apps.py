from django.apps import AppConfig


class MyfirstappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'MyFirstApp'
