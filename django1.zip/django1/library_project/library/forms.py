from django import forms
from django.core.exceptions import  ValidationError
from django.utils import timezone
from .models import Author

# class BookForm(forms.ModelForm):
#     class Meta:
#         model = Book
#         fields=['title','publication_date','authors','category']
#         widgets={
#             'publication_date':forms.SelectDateWidget(years=range(1700,timezone.now().year+1)),
#             'authors':forms.CheckboxSelectMultiple(),
#         }


class AuthorForm(forms.ModelForm):
    class Meta:
        model=Author
        fields=['name','bio']

    def clean_name(self):
        name=self.cleaned_data.get('name')
        if not name:
            raise ValidationError('name is required')
        return name
