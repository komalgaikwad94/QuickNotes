from django.shortcuts import render
from .forms import (Login_Form)


def form_home(request):
    return render(request,'form/index.html')


def login_form(request):
    form=Login_Form()
    if request.method=="POST":
        form=Login_Form(request.POST)
        if form.is_valid():
            data=form.cleaned_data
            p1=data.get('password')
            p2=data.get('confirm_password')
            if  p1 != p2:
                msg='Password not match !'
                print(msg)
                return render(request,'form/form_template.html',{'form':form,'message':'password does not exits'})
            else:
                return render(request, 'form/success.html', {'form': form})

    return render(request,'form/form_template.html',{"form": form, "title": "LoginForm"})

