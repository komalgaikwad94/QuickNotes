from django.apps import AppConfig


class FormsFieldsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Forms_Fields'
