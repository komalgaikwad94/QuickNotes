from django.http import HttpResponse
from django.shortcuts import render


def FirstApp(request):
    return HttpResponse("<h1>This is First App</h1>")


def Nav(request):
    return render(request,'MyFirstApp/index.html')